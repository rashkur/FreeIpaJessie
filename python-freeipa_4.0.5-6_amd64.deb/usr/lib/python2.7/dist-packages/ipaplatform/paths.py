# Authors:
#   Timo Aaltonen <tjaalton@ubuntu.com>
#
# Copyright (C) 2014 Timo Aaltonen
# see file 'COPYING' for use and warranty information
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

"""
This Debian base platform module exports default filesystem paths as common
in Debian-based systems.
"""

# Fallback to default path definitions
from ipaplatform.base.paths import BasePathNamespace


class DebianPathNamespace(BasePathNamespace):
    ETC_HTTPD_DIR = "/etc/apache2"
    HTTPD_ALIAS_DIR = "/etc/apache2/nssdb"
    ALIAS_CACERT_ASC = "/etc/apache2/nssdb/cacert.asc"
    ALIAS_PWDFILE_TXT = "/etc/apache2/nssdb/pwdfile.txt"
    HTTPD_CONF_D_DIR = "/etc/apache2/conf-enabled/"
    HTTPD_IPA_PKI_PROXY_CONF = "/etc/apache2/conf-enabled/ipa-pki-proxy.conf"
    HTTPD_IPA_REWRITE_CONF = "/etc/apache2/conf-available/ipa-rewrite.conf"
    HTTPD_IPA_CONF = "/etc/apache2/conf-enabled/ipa.conf"
    HTTPD_NSS_CONF = "/etc/apache2/mods-available/nss.conf"
    IPA_KEYTAB = "/etc/apache2/ipa.keytab"
    HTTPD_PASSWORD_CONF = "/etc/apache2/password.conf"
    NAMED_CONF = "/etc/bind/named.conf"
    NAMED_KEYTAB = "/etc/bind/named.keytab"
    NAMED_RFC1912_ZONES = "/etc/bind/named.conf.default-zones"
    OPENLDAP_LDAP_CONF = "/etc/ldap/ldap.conf"
    ETC_DEBIAN_VERSION = "/etc/debian_version"
    ETC_SYSCONFIG_DIR = "/etc/default"
    SYSCONFIG_AUTOFS = "/etc/default/autofs"
    SYSCONFIG_DIRSRV = "/etc/default/dirsrv"
    SYSCONFIG_DIRSRV_INSTANCE = "/etc/default/dirsrv-%s"
    SYSCONFIG_DIRSRV_SYSTEMD = "/etc/default/dirsrv.systemd"
    SYSCONFIG_KRB5KDC_DIR = "/etc/default/krb5-kdc"
    SYSCONFIG_NFS = "/etc/default/nfs-common"
    SYSCONFIG_NTPD = "/etc/default/ntp"
    SYSCONFIG_PKI = "/etc/dogtag/"
    SYSCONFIG_PKI_TOMCAT = "/etc/default/pki-tomcat"
    SYSCONFIG_PKI_TOMCAT_PKI_TOMCAT_DIR = "/etc/dogtag/tomcat/pki-tomcat"
    SBIN_SERVICE = "/usr/sbin/service"
    BIND_LDAP_SO = "/usr/share/doc/bind9-dyndb-ldap/copyright"
    LIB_SYSTEMD_SYSTEMD_DIR = "/lib/systemd/system/"
    HTTPD = "/usr/sbin/apache2ctl"
    SETUP_DS_PL = "/usr/sbin/setup-ds"
    VAR_KERBEROS_KRB5KDC_DIR = "/var/lib/krb5kdc/"
    VAR_KRB5KDC_K5_REALM = "/var/lib/krb5kdc/.k5."
    CACERT_PEM = "/var/lib/krb5kdc/cacert.pem"
    KRB5KDC_KDC_CONF = "/var/lib/krb5kdc/kdc.conf"
    KDC_PEM = "/var/lib/krb5kdc/kdc.pem"
    VAR_LOG_HTTPD_DIR = "/var/log/apache2"
    GENERATE_RNDC_KEY = "/usr/share/ipa/generate-rndc-key.sh"

paths = DebianPathNamespace()
